//
//  CalculatorView.swift
//  App3
//
//  Created by LUNVCA on 10/21/16.
//  Copyright © 2016 uca. All rights reserved.
//

import UIKit
import Foundation



class CalculatorView: UIViewController {
    
    var myConfig = ConfigData()
    
    
    @IBOutlet fileprivate var one : UIButton!
    @IBOutlet fileprivate var two : UIButton!
    @IBOutlet fileprivate var three : UIButton!
    @IBOutlet fileprivate var four : UIButton!
    @IBOutlet fileprivate var five : UIButton!
    @IBOutlet fileprivate var six : UIButton!
    @IBOutlet fileprivate var seven : UIButton!
    @IBOutlet fileprivate var eight : UIButton!
    @IBOutlet fileprivate var nine : UIButton!
    @IBOutlet fileprivate var zero : UIButton!
    @IBOutlet fileprivate var pi : UIButton!
    @IBOutlet fileprivate var sqrroot : UIButton!
    @IBOutlet fileprivate var plus : UIButton!
    @IBOutlet fileprivate var minus : UIButton!
    @IBOutlet fileprivate var multiply : UIButton!
    @IBOutlet fileprivate var divide : UIButton!
    @IBOutlet fileprivate var sin : UIButton!
    @IBOutlet fileprivate var cos : UIButton!
    @IBOutlet fileprivate var tan : UIButton!
    @IBOutlet fileprivate var ln : UIButton!
    @IBOutlet fileprivate var openp : UIButton!
    @IBOutlet fileprivate var closep : UIButton!
    @IBOutlet fileprivate var decimal : UIButton!
    @IBOutlet fileprivate var x : UIButton!
    @IBOutlet fileprivate var expx : UIButton!
    @IBOutlet fileprivate var plusminus : UIButton!
    @IBOutlet fileprivate var clear : UIButton!
    @IBOutlet fileprivate var plot : UIButton!
    @IBOutlet fileprivate var equationfield : UITextField!
    fileprivate var equationstring : String = ""
    fileprivate var exptoggle : Int = 0
    
    
    
   
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.one.setTitle("1", for: UIControlState())
        self.two.setTitle("2", for: UIControlState())
        self.three.setTitle("3", for: UIControlState())
        self.four.setTitle("4", for: UIControlState())
        self.five.setTitle("5", for: UIControlState())
        self.six.setTitle("6", for: UIControlState())
        self.seven.setTitle("7", for: UIControlState())
        self.eight.setTitle("8", for: UIControlState())
        self.nine.setTitle("9", for: UIControlState())
        self.zero.setTitle("0", for: UIControlState())
        self.pi.setTitle("π", for: UIControlState())
        self.sqrroot.setTitle("√(", for: UIControlState())
        self.minus.setTitle("-", for: UIControlState())
        self.plus.setTitle("+", for: UIControlState())
        self.multiply.setTitle("*", for: UIControlState())
        self.divide.setTitle("÷", for: UIControlState())
        self.sin.setTitle("sin(", for: UIControlState())
        self.cos.setTitle("cos(", for: UIControlState())
        self.tan.setTitle("tan(", for: UIControlState())
        self.ln.setTitle("ln(", for: UIControlState())
        self.openp.setTitle("(", for: UIControlState())
        self.closep.setTitle(")", for: UIControlState())
        self.decimal.setTitle(".", for: UIControlState())
        self.x.setTitle("x", for: UIControlState())
        self.expx.setTitle("", for: UIControlState())
        self.plusminus.setTitle("-", for: UIControlState())
        self.clear.setTitle("clear", for: UIControlState())
        
        let tbc = tabBarController as! TabControl
        myConfig = tbc.myConfig
        
       
        
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
         self.navigationController!.hidesBarsOnTap = false
        self.navigationController!.isNavigationBarHidden = true
               
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func exptoggle(_ exptoggle: UIButton)
        
    {self.exptoggle = 1
     self.equationfield.text = self.equationfield.text! + "x"
     
        
    }

    
    @IBAction func pressbutton(_ calcbutton: UIButton)
    {
        
        let thistitle = calcbutton.currentTitle!
        
        if(exptoggle == 1)
        {
            if( thistitle == "1")
            {
            self.equationfield.text = self.equationfield.text! + "¹"
            self.equationstring = self.equationstring + "(x^1)"
            
            }
            else if (thistitle == "2")
            {
            self.equationfield.text = self.equationfield.text! + "²"
            self.equationstring = self.equationstring + "(x^2)"
            }
            else if (thistitle == "3")
            {
            self.equationfield.text = self.equationfield.text! + "³"
            self.equationstring = self.equationstring + "(x^3)"
            }

            else if (thistitle == "4")
            {
            self.equationfield.text = self.equationfield.text! + "⁴"
            self.equationstring = self.equationstring + "(x^4)"
            }

            else if (thistitle == "5")
            {
            self.equationfield.text = self.equationfield.text! + "⁵"
            self.equationstring = self.equationstring + "(x^5)"
            }

            else if (thistitle == "6")
            {
            self.equationfield.text = self.equationfield.text! + "⁶"
            self.equationstring = self.equationstring + "(x^6)"
            }

            else if (thistitle == "7")
            {
              self.equationfield.text = self.equationfield.text! + "⁷"
            self.equationstring = self.equationstring + "(x^7)"
            }
            else if (thistitle == "8")
            {
              self.equationfield.text = self.equationfield.text! + "⁸"
            self.equationstring = self.equationstring + "(x^8)"
            }
            else if (thistitle == "9")
            {
               self.equationfield.text = self.equationfield.text! + "⁹"
            self.equationstring = self.equationstring + "(x^9)"
            }
            else if (thistitle == "0")
            {
               self.equationfield.text = self.equationfield.text! + "⁰"
            self.equationstring = self.equationstring + "(x^0)"
            }

            


        }
        if(thistitle == "π")
        {
        self.equationfield.text! = self.equationfield.text! + thistitle
        self.equationstring = self.equationstring + "3.14"
        
        }
        
        if(thistitle == "÷")
        {
            self.equationfield.text! = self.equationfield.text! + thistitle
            self.equationstring = self.equationstring + "/"
            
        }

        else if(thistitle == "√(")
        {
            self.equationfield.text! = self.equationfield.text! + thistitle
            self.equationstring = self.equationstring + "sqrt("

        }
        
        else if((thistitle != "√(") && (thistitle != "÷") && (thistitle != "π")) && (self.exptoggle != 1)
        {
        
        print (thistitle )
        self.equationfield.text! = self.equationfield.text! + thistitle
        self.equationstring = self.equationstring + thistitle
        }
        self.exptoggle = 0
    }
    @IBAction func clearbutton(_ clearbutton: UIButton)
    {
        self.equationfield.text! = ""
        self.equationstring = ""
    }
    
   
    
    @IBAction func plotbutton(_ plotbutton: UIButton)
    {
        
        print("From Calc:" , equationstring)
        
       
    }
    
   
   
    
    
    // MARK: - Navigation

    //In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
            if(segue.identifier == "plot") {
                
            let yourNextViewController = (segue.destination as! Plotter)
                yourNextViewController.equationstring = self.equationstring
                yourNextViewController.myConfig = self.myConfig
    }
    

}
}
