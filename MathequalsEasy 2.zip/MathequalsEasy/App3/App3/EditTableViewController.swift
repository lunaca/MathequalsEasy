
import UIKit

class EditTableViewController: UITableViewController, UITextFieldDelegate, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // Model:
    var SolveIt: SolveIt?
    
    @IBOutlet weak var SolveItImageViewing: UIImageView!
  

    // MARK: - VC Lifecycle
    
   override func viewDidLoad() {
        super.viewDidLoad()
        title = "Edit SolveIt"
        SolveItImageViewing.image = SolveIt?.image
     
    }
    
    override func viewWillDisappear(_ animated: Bool) {
      
        SolveIt?.image = SolveItImageViewing.image!
    }
    lazy var SolveItLines: [SolveItLine] = {
        return SolveItLine.SolveItLines()
    }()
    
    var SolveItShown = [Bool](repeating: false, count: SolveItLine.numberOfSolveIt)
    

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let SolveItLine = SolveItLines[section]
        return SolveItLine.name
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let SolveItLine = SolveItLines[section]
        return SolveItLine.equations.count   // the number of SolveIts in the section
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> EquationTableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Equation Cell", for: indexPath)
        

        let SolveItLine = SolveItLines[indexPath.section]
        let SolveIt = SolveItLine.equations[indexPath.row]

        
        //cell.configureCellWith(SolveIt)
        
        return cell as! EquationTableViewCell
    }

    // MARK: - UIScrollViewDelegate
    
 
    // MARK: - Table View Interaction
    
    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        if indexPath.section == 0 && indexPath.row == 0 {
            return indexPath
        } else {
            return nil
        }
    }
    
    
}





























