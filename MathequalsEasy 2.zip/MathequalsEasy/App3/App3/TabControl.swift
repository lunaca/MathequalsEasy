//
//  TabControl.swift
//  App3
//
//  Created by LUNVCA on 10/25/16.
//  Copyright © 2016 uca. All rights reserved.
//

import UIKit

class TabControl: UITabBarController {

   var myConfig = ConfigData()
}
