//
//  Plotter.swift
//  App3
//
//  Created by LUNVCA on 10/25/16.
//  Copyright © 2016 uca. All rights reserved.
//

import UIKit

class Plotter: UIViewController {
    var point = [Double]()
    var equationstring : String!
    var myConfig = ConfigData()
    var offset : Double = 0.0
    var ymax : Double = 0.0
    
    @IBOutlet var graph : UIImageView!
    
    @IBOutlet var xmaxl : UILabel!
    @IBOutlet var xminl : UILabel!
    @IBOutlet var ymaxl : UILabel!
    @IBOutlet var yminl : UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(myConfig.currentconfig())
        print(equationstring)
        buildthepoints()
        graphdempoints()
        var roundedymax : Double = 0.0
        roundedymax = Double(round(100*ymax)/100)
        xmaxl.text = String(self.myConfig.x_max)
        ymaxl.text = String(roundedymax)
        xminl.text = String( -self.myConfig.x_max)
        yminl.text = String(-roundedymax)
        
        self.navigationController!.hidesBarsOnTap = true
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func buildthepoints()
    {
        self.offset  = 2*(self.myConfig.x_max/Double(self.myConfig.samples))
        print("the offset is" , offset)
        var i = 0
        var xcounter = Double(-self.myConfig.x_max)
        print(xcounter)
        
        
        
        for i in 0..<myConfig.samples
        {
            //Create a parser
            let a = GCMathParser()
            
            //Set a mathematical expression
            let exp = equationstring
            
            //Get an x_value – from the text field (notice how we convert to double)
            let x = xcounter
            
            //Set up the x value for the parser
            a.setSymbolValue (x , forKey: "x")
            
            //Get the y value
            let y = a.evaluate(exp)
            if(y > ymax)
            {
             ymax = y
            }
            print(y)
            point.append(y)
            xcounter = xcounter + offset
        }
    }
        
    func graphdempoints()
    {
        var width = self.view.frame.size.width
        var height = self.view.frame.size.height
        
        let widthImage = graph.frame.size.width
        let heightImage = graph.frame.size.height
        let originY = Double(view.frame.minY)
        let x_plot_max = Double( widthImage/2)
        let y_plot_max = (Double(heightImage) + originY)/2
        
        let cx = Double(widthImage/2)
        let cy = Double(heightImage/2)
        
        
        
        let x_max = self.myConfig.x_max
        let y_max = ymax
        
        var x_plot :Double = 0.0
        var y_plot :Double = 0.0
        
        var i = 0
        var x = -myConfig.x_max
        for i in 0..<myConfig.samples
        
        {
            if ((x > 0) && (point[i] > 0))
            {
            x_plot = cx + (fabs(x)/x_max) * x_plot_max
            y_plot = cy - (fabs(point[i])/y_max)*y_plot_max
            }
            
            else if((x < 0) && (point[i] > 0))
            {
            x_plot = cx - (fabs(x)/x_max)*x_plot_max
            y_plot = cy - (fabs(point[i])/y_max)*y_plot_max
            }
            else if ((x < 0) && ( point[i] < 0))
            {
            x_plot = cx - (fabs(x)/x_max)*x_plot_max
            y_plot = cy + (fabs(point[i])/y_max)*y_plot_max
            }
            else if  ((x > 0) && (point[i] < 0))
            {
            x_plot = cx + (fabs(x)/x_max)*x_plot_max
            y_plot = cy + (fabs(point[i])/y_max)*y_plot_max
            }
            
            let label = UILabel()
            label.frame = CGRect(x: CGFloat(x_plot), y: CGFloat(y_plot), width: 4.0, height: 4.0)
            label.backgroundColor = UIColor.red;
            
            self.view.addSubview(label)

            
            x = x + self.offset
        
        }
        
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


