
import UIKit

class SolveItDetailViewController: UIViewController
{
    // Model
    var SolveIt: SolveIt?

    @IBOutlet weak var SolveItImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SolveItImageView.image = SolveIt?.image
    }

}
