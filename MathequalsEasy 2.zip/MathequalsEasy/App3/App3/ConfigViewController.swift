//
//  ConfigViewController.swift
//  App3
//
//  Created by LUNVCA on 10/25/16.
//  Copyright © 2016 uca. All rights reserved.
//

import UIKit

class ConfigViewController: UIViewController {
 
    var myConfig = ConfigData()
   
    @IBOutlet var xmaxfield : UITextField!
    @IBOutlet var samplefield : UITextField!
    @IBOutlet var set1 : UIButton!
    @IBOutlet var set2 : UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tbc = tabBarController as! TabControl
        myConfig = tbc.myConfig
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func setxmaxfield(_ sender: UIButton)
    {
        self.myConfig.x_max = Double(xmaxfield.text!)!
        print(self.myConfig.x_max)
        xmaxfield.resignFirstResponder()
    }
    @IBAction func setsamplefield(_ sender: UIButton)
    {
        self.myConfig.samples = Int(samplefield.text!)!
        print(self.myConfig.samples)
        samplefield.resignFirstResponder()

        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
