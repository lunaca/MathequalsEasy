
import UIKit

class SolveItTableViewController: UITableViewController {
    
    // MARK: - VC Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let infoImage = UIImage(named: "search_filled-32.png")
        let imgWidth = infoImage?.size.width
        let imgHeight = infoImage?.size.height
        let button:UIButton = UIButton(frame: CGRect(x: 0,y: 0,width: imgWidth!, height: imgHeight!))
        button.setBackgroundImage(infoImage, for: .normal)
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
     
        
        // Make the row height dynamic
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    

    // MARK: - Data Source
    
    lazy var SolveItLines: [SolveItLine] = {
        return SolveItLine.SolveItLines()
    }()
    
    var SolveItShown = [Bool](repeating: false, count: SolveItLine.numberOfSolveIt)
    
    // MARK: - UITableViewDataSource
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let SolveItLine = SolveItLines[section]
        return SolveItLine.name
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return SolveItLines.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let SolveItLine = SolveItLines[section]
        return SolveItLine.courses.count   // the number of SolveIts in the section
    }

    // indexPath: which section and which row
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SolveIt Cell", for: indexPath) as! SolveItTableViewCell

        let SolveItLine = SolveItLines[indexPath.section]
        let SolveIt = SolveItLine.courses[indexPath.row]
        
        cell.configureCellWith(SolveIt)
        
        return cell
    }
    
    // MARK: - Edit Tableview
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            let SolveItLine = SolveItLines[indexPath.section]
            SolveItLine.courses.remove(at: indexPath.row)
            // tell the table view to update with new data source
//            tableView.reloadData()    Bad way!
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
        }
    }
    
    // MARK: - Animate Table View Cell
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        // first
        
        if SolveItShown[indexPath.row] == false {
            
            let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, -500, 10, 0)
            cell.layer.transform = rotationTransform
            
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                
                cell.layer.transform = CATransform3DIdentity
                
            })
            
            SolveItShown[indexPath.row] = true
            
        }
    }
      
    
    // performSegueWithIdentifier(identifier: "", sender: AnyObject?)
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let identifier = segue.identifier {
            switch identifier {
                case "Show Detail":
                    let SolveItDetailVC = segue.destination as! EditTableViewController
                    if let indexPath = self.tableView.indexPath(for: sender as! UITableViewCell) {
                        SolveItDetailVC.SolveIt = SolveItAtIndexPath(indexPath)
                    }
                case "Show Edit":
                    let editTableVC = segue.destination as! EditTableViewController
                    if let indexPath = self.tableView.indexPath(for: sender as! UITableViewCell) {
                        editTableVC.SolveIt = SolveItAtIndexPath(indexPath)
                    }
                
                default: break
            }
        }
    }
    
    // MARK: - Helper Method
    
    func SolveItAtIndexPath(_ indexPath: IndexPath) -> SolveIt
    {
        let SolveItLine = SolveItLines[indexPath.section]
        return SolveItLine.courses[indexPath.row]
    }
    
}







































