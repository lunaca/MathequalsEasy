//
//  ConfigData.swift
//  App3
//
//  Created by LUNVCA on 10/25/16.
//  Copyright © 2016 uca. All rights reserved.
//

import UIKit

class ConfigData: NSObject {
    
        var x_max : Double = 5
        var samples : Int  = 50
        
        func currentconfig(){ //return a string with the current order
            print ( self.x_max)
            print (self.samples)}


}