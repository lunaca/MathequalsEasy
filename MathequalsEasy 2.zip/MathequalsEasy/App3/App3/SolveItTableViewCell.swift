

import UIKit

class SolveItTableViewCell: UITableViewCell {

    @IBOutlet weak var SolveItImageView: UIImageView!
    @IBOutlet weak var SolveItDescriptionLabel: UILabel!
    @IBOutlet weak var SolveItTitleLabel: UILabel!
    
    func configureCellWith(_ SolveIt: SolveIt)
    {
        SolveItImageView.image = SolveIt.image
        SolveItDescriptionLabel.text = SolveIt.description
        SolveItTitleLabel.text = SolveIt.title
    }
  
}
