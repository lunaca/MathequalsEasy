

import Foundation
import UIKit

public enum SolveItRating
{
    case unrated
    case average
    case ok
    case good
    case brilliant
}

// Represents a generic SolveIt. Need an image named "default"

class SolveIt
{
    var title: String
    var description: String
    var image: UIImage
    var rating: SolveItRating
    
    init(titled: String, description: String, imageName: String)
    {
        self.title = titled
        self.description = description
        if let img = UIImage(named: imageName) {
            image = img
        } else {
            image = UIImage(named: "default")!
        }
        rating = .unrated
    }
}










