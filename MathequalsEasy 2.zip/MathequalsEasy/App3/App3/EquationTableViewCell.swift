//
//  EquationTableViewCell.swift
//  App3
//
//  Created by LUNVCA on 2/14/17.
//  Copyright © 2017 uca. All rights reserved.
//

import Foundation

import UIKit

class EquationTableViewCell: UITableViewCell {
    
  
    @IBOutlet weak var EquationTitleLabel: UILabel!
    
    func configureCellWith(_ SolveIt: SolveIt)
    {
       EquationTitleLabel.text = SolveIt.title
    }
    
}
