
import Foundation

class SolveItLine
{
    // Variables
    var name: String            // name of the SolveIt line
    var courses: [SolveIt]     // all SolveIt in the line
    var equations: [String] // all equations
    
    class var numberOfSolveIt: Int {
        get {
            //return (SolveItLine.iDevices().courses.count + SolveItLine.mac().courses.count + SolveItLine.software().courses.count + SolveItLine.iPod().courses.count )
        return (SolveItLine.chemistry().courses.count + SolveItLine.Physics().courses.count)
        }
    }
    
    init(named: String, includeSolveIt: [SolveIt])
    {
        name = named
        courses = includeSolveIt
        equations = ["hell", "yes", "mother", "fucker"]
    }
    
    class func SolveItLines() -> [SolveItLine]
    {
        return [self.chemistry(), self.Physics()]
    }
    
    // Private methods
    
    fileprivate class func chemistry() -> SolveItLine {
        //  (1) iDevices: Apple Watch, iPad, iPhone, iOS
        var courses = [SolveIt]()
        
        courses.append(SolveIt(titled: "General Chemistry I", description: "Fundamental skills for chemistry including the concept of energy and its uses, gas laws, kinetic molecular theory, laws of chemical combination, atomic and molecular structure, periodic classification of the elements, and chemical bonding.", imageName: "genchem.jpg"))
        courses.append(SolveIt(titled: "General Chemistry II", description: "An introduction to the principles of chemical equilibrium and chemical change. Topics include chemical equilibria, acid/base chemistry, and other ionic equilibria, electrochemistry, elementary chemical thermodynamics and kinetics.", imageName: "genchem2.png"))
        courses.append(SolveIt(titled: "BioChemistry", description: "Organochemical concepts used to explore the structure, reactivity and pathways of biosynthesis of alkaloids, proteins, saccharides, nucleic acids, and other natural products, and to examine the molecular basis of drug action.", imageName: "BioChem.jpeg"))
        courses.append(SolveIt(titled: "Organic Chemistry", description: "Encompasses special emphasis on the mechanisms and the synthetic applications of organic reactions and on the organic chemistry of biological compounds.", imageName: "organic.jpg"))
        
        return SolveItLine(named: "Chemistry", includeSolveIt: courses)
        
    }
    fileprivate class func Physics() -> SolveItLine {
        //  (1) iDevices: Apple Watch, iPad, iPhone, iOS
        var courses = [SolveIt]()
        
        courses.append(SolveIt(titled: "General Physics I", description: "This course uses algebra- and trigonometry-based mathematical models to introduce the fundamental concepts that describe the physical world. Topics include units and measurement, vectors, linear kinematics and dynamics, energy, power, momentum, fluid mechanics, and heat.", imageName: "phys1.jpg"))
        courses.append(SolveIt(titled: "Astrophysics", description: "is the branch of astronomy that employs the principles of physics and chemistry to ascertain the nature of the heavenly bodies, rather than their positions or motions in space.", imageName: "astrophysics.jpg"))
        courses.append(SolveIt(titled: "BioPhysics", description: "Molecular biophysics typically addresses biological questions similar to those in biochemistry and molecular biology, but more quantitatively, seeking to find the physical underpinnings of biomolecular phenomena.", imageName: "biophys.jpg"))
        courses.append(SolveIt(titled: "Chemical Physics", description: "Chemical physics is a subdiscipline of chemistry and physics that investigates physicochemical phenomena using techniques from atomic and molecular physics and condensed matter physics; it is the branch of physics that studies chemical processes from the point of view of physics..", imageName: "chemphys.jpg"))
        
        return SolveItLine(named: "Physics", includeSolveIt: courses)
    }
    //  (2) Mac: MacBook, MacBook Pro with Retina Display, MacBook Air, iMac
    //           Mac Pro, MacBook Pro, Mac Mini, Display, Airport Extreme,
    //           AirPort Time Capsule, AirPort Express, Magic Trackpad
    //           Magic Mouse, Apple Keyboard, Apple Battery Charger
    
//    fileprivate class func mac() -> SolveItLine
//    {
//        var courses = [SolveIt]()
//        
//        courses.append(SolveIt(titled: "MacBook", description: "The thinnest and lightest Mac ever with every component meticulously redesigned to create a Mac that is just two pounds and 13.1 mm thin. ", imageName: "macbook.png"))
//        courses.append(SolveIt(titled: "MacBook Pro 13 inch", description: "MacBook Pro features the latest dual-core and quad-core processors, and faster graphics to deliver the perfect combination of pro performance and extreme portability.", imageName: "macbook-pro-13.png"))
//        courses.append(SolveIt(titled: "MacBook Pro with Retina Display", description: "A stunning high-resolution display, an amazing thin and light design, and the latest technology to power through the most demanding projects.", imageName: "macbook-pro-retina.png"))
//        courses.append(SolveIt(titled: "MacBook Air", description: "All day battery life, fourth generation Intel Core processors with faster graphics, 802.11ac Wi-Fi and flash storage that is up to 45 percent faster than the previous generation.", imageName: "macbook-air.png"))
//        courses.append(SolveIt(titled: "iMac", description: "The 27-inch iMac with Retina 5K display features a breathtaking 14.7 million pixel display so text appears sharper than ever, videos are unbelievably lifelike.", imageName: "imac-5k.png"))
//        courses.append(SolveIt(titled: "Mac Pro", description: "Designed around a revolutionary unified thermal core, the Mac Pro introduces a completely new pro desktop architecture and design that is optimized for performance inside and out.", imageName: "mac-pro.png"))
//        courses.append(SolveIt(titled: "Mac Mini", description: "With its sleek aluminum design, a removable bottom panel for easy access to memory, and a space-saving built-in power supply, Mac mini is pretty incredible.", imageName: "mac-mini.png"))
//        courses.append(SolveIt(titled: "Displays", description: "The 27-inch Apple LED Cinema Display supersizes your view with an incredible 2560-by-1440 resolution.", imageName: "display.png"))
//        courses.append(SolveIt(titled: "Airport Extreme", description: "Featuring 802.11ac Wi-Fi for up to three times faster performance.", imageName: "airport-extreme.png"))
//        
//        return SolveItLine(named: "Mac", includeSolveIt: courses)
//    }
//    
//    //  (3) Software: OS X, iLife, iWork, Logic Pro X, Final Cut Pro X, Aperture
//    
//    fileprivate class func software() -> SolveItLine
//    {
//        var courses = [SolveIt]()
//        
//        courses.append(SolveIt(titled: "OS X", description: "Built on a rock-solid UNIX foundation, OS X is engineered to take full advantage of the technologies in every new Mac.", imageName: "os-x.png"))
//        courses.append(SolveIt(titled: "iLife", description: "Do more with movies and music than you ever thought possible.", imageName: "ilife.png"))
//        courses.append(SolveIt(titled: "iWork", description: " iWork is the easiest way to create great-looking documents, spreadsheets, and presentations. ", imageName: "iwork.png"))
//        courses.append(SolveIt(titled: "Logic Pro X", description: "Logic Pro X, the most advanced version of Logic Pro to date, with a new interface designed for pros.", imageName: "logic-pro-x.png"))
//        courses.append(SolveIt(titled: "Final Cut Pro X", description: "A revolutionary new version of the world’s most popular Pro video editing software which completely reinvents video editing.", imageName: "final-cut-pro-x.png"))
//        courses.append(SolveIt(titled: "Aperture", description: "Featuring revolutionary new technologies and a pioneering user interface with a beautiful design that honors the rich tradition of precision watchmaking.", imageName: "aperture.png"))
//        
//        return SolveItLine(named: "Software", includeSolveIt: courses)
//    }
//    
//    //  (4) iPod: Apple TV, iPod nano, iPod shuffle, iPod touch, iTunes
//    
//    fileprivate class func iPod() -> SolveItLine
//    {
//        var courses = [SolveIt]()
//        
//        courses.append(SolveIt(titled: "iPod nano", description: "The thinnest iPod ever featuring a 2.5-inch Multi-Touch display; convenient navigation buttons; built-in Bluetooth for wireless listening; and the iPod nano comes in seven gorgeous colors.", imageName: "ipod-nano.png"))
//        courses.append(SolveIt(titled: "iPod shuffle", description: "Crafted from a single piece of aluminium and polished to a beautiful shine, iPod shuffle feels solid, sleek and durable.", imageName: "ipod-shuffle.png"))
//        courses.append(SolveIt(titled: "iPod touch", description: "Featuring a brilliant 4-inch Retina display; a 5-megapixel iSight camera with 1080p HD video recording.", imageName: "ipod-touch.png"))
//        courses.append(SolveIt(titled: "iTunes", description: "A free application for your Mac or PC, iTunes organizes and plays your digital music and video on your computer.", imageName: "itunes.png"))
//        courses.append(SolveIt(titled: "Apple TV", description: "Access to tons of great HD content in a tiny package. Enjoy blockbuster movies, TV shows, live sports and news, your music, photos, and more — right on your high-definition TV.", imageName: "apple-tv.png"))
//        
//        return SolveItLine(named: "iPod and iTunes", includeSolveIt: courses)
//    }
//    
    
}













